-- This resource was made by plesalex100#7387
-- Please respect it, don't repost it without my permission
-- This Resource started from: https://codepen.io/AdrianSandu/pen/MyBQYz
-- Converted to Latest QBCore by JustifY#9606

Config = {}

Config.MaxBetNumbers = 4 -- 4 makes the max buyin 9999, 5 makes the max buyin 99999 etc.

AddTextEntry('TEST_LUCK', 'Press ~INPUT_VEH_HORN~ to test your luck')        -- Text for external detach point